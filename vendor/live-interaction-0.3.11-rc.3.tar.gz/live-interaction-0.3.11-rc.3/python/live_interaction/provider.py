#!/usr/bin/env python3
"""Shared Gemini Live transport. Product tools and instructions arrive at setup."""
import asyncio
import base64
import json
import logging
import inspect
import os
import re
import sys
import time
from urllib.parse import quote
from websockets.exceptions import ConnectionClosed

ENDPOINT = 'wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent'
MODELS = {'gemini-3.8-live', 'gemini-3.8-live-extended-thinking'}
FRESH_HANDLE_WAIT_SECONDS = 8
TRANSITION_DEADLINE_SECONDS = 95
MAX_TRANSITION_CONNECTION_ATTEMPTS = 3
MAX_TRANSITION_BUDGET_RETRIES = 30
TRANSITION_BUDGET_RETRY_SECONDS = 3
SEND_BUDGET_DEADLINE_SECONDS = 95
MAX_HISTORY_TURNS = 8
MAX_HISTORY_TEXT = 700
OUTPUT_PCM_CHUNK_BYTES = 11000


class DialogueHistory:
    """Bounded completed utterances, not individual transcription packets.

    Gemini does not guarantee input transcription ordering relative to other
    server messages. A late input fragment can still extend the last user turn
    until the next client input begins; exact ASR-to-turn attribution is not
    possible without provider turn IDs.
    """
    def __init__(self, initial=()):
        self.turns = []
        for item in initial if isinstance(initial, list) else []:
            if isinstance(item, dict) and item.get('role') in ('user', 'model') and isinstance(item.get('text'), str):
                self._commit(item['role'], item['text'])
        self.pending = {'user': '', 'model': ''}
        self.late_user_turn = None

    @staticmethod
    def _bounded(value):
        value = value.strip()
        if len(value) <= MAX_HISTORY_TEXT:
            return value
        return value[:350].rstrip() + ' … ' + value[-346:].lstrip()

    def _commit(self, role, text):
        text = self._bounded(text)
        if text:
            self.turns.append({'role': role, 'text': text})
            self.turns = self.turns[-MAX_HISTORY_TURNS:]

    @staticmethod
    def _join(current, fragment):
        fragment = fragment.strip()
        if not fragment or current.endswith(fragment):
            return current
        if fragment.startswith(current):
            return fragment[:4000]
        overlap = min(len(current), len(fragment))
        while overlap and current[-overlap:] != fragment[:overlap]:
            overlap -= 1
        if overlap < 3:
            overlap = 0
        return (current + ('' if overlap or not current or current.endswith((' ', '\n')) else ' ') + fragment[overlap:])[:4000]

    def input_started(self):
        self.late_user_turn = None

    def transcript(self, role, text):
        if not isinstance(text, str) or not text.strip():
            return
        if role == 'user' and self.late_user_turn is not None and self.late_user_turn in self.turns:
            self.late_user_turn['text'] = self._bounded(self._join(self.late_user_turn['text'], text))
            return
        self.pending[role] = self._join(self.pending[role], text)

    def complete(self):
        if self.pending['user']:
            self._commit('user', self.pending['user'])
            self.late_user_turn = self.turns[-1]
        if self.pending['model']:
            self._commit('model', self.pending['model'])
        self.pending = {'user': '', 'model': ''}

    def snapshot(self):
        self.complete()
        return [dict(item) for item in self.turns]

    def metrics(self):
        return {'history_turns': len(self.turns),
                'history_chars': sum(len(item['text']) for item in self.turns)}

def emit(payload):
    payload['provider_at'] = round(time.time() * 1000)
    print(json.dumps(payload, ensure_ascii=False, separators=(',', ':')), flush=True)


def default_key():
    return os.environ.get('LIVE_API_KEY')


def _guard_check(resource_guard):
    if resource_guard is not None:
        resource_guard.check()


async def _guarded_send(ws, payload, resource_guard=None):
    _guard_check(resource_guard)
    if resource_guard is not None:
        pending = resource_guard.before_send(payload)
        if inspect.isawaitable(pending):
            await pending
        _guard_check(resource_guard)
    await ws.send(json.dumps(payload))
    _guard_check(resource_guard)


async def _send_with_budget_wait(ws, payload, resource_guard, emit, kind, state, *, optional=False, deadline_seconds=SEND_BUDGET_DEADLINE_SECONDS):
    """Retry admission for one unsent control message; never rerun a product tool.

    A frame is optional and can be dropped. Live PCM cannot safely wait behind a
    rolling quota because the real-time queue would become stale, so it remains
    fail-fast. Tool results and text are already durable/ordered before send.
    """
    loop = asyncio.get_running_loop()
    deadline = loop.time() + deadline_seconds
    retries = 0
    while True:
        try:
            await _guarded_send(ws, payload, resource_guard)
            if retries:
                state['drop_capture_before'] = round(time.time() * 1000)
                emit({'type':'resource_budget_ready','input_type':kind,'retries':retries})
            return True
        except Exception as exc:
            if not (_is_resource_failure(exc) and getattr(exc,'code',None)=='RESOURCE_TOKEN_BUDGET'):
                raise
            if kind == 'snapshot' and optional:
                emit({'type':'input_dropped','reason':'resource_budget','input_type':kind})
                return False
            if kind not in ('tool_response','text','audio_stream_end','activity_end','activity_start'):
                raise
            remaining = deadline - loop.time()
            if remaining <= 0 or state['stopped'] or state['ws'] is not ws:
                raise
            retries += 1
            state['drop_capture_before'] = round(time.time() * 1000)
            wait_seconds = min(remaining, max(.05, min(5, getattr(exc,'retry_after_ms',3000) / 1000 or 3)))
            emit({'type':'resource_budget_wait','input_type':kind,'retry':retries,'wait_ms':round(wait_seconds*1000)})
            await asyncio.sleep(wait_seconds)


async def _guarded_recv(ws, resource_guard=None):
    _guard_check(resource_guard)
    raw = await ws.recv()
    _guard_check(resource_guard)
    return raw


def _is_resource_failure(exc):
    return bool(getattr(exc, 'resource_failure', False))


async def read_line(reader):
    line = await reader.readline()
    if not line:
        return None
    return json.loads(line.decode('utf-8'))


def _application_search_function(configuration, functions):
    name = str((configuration or {}).get('application_search_function') or '').strip()
    if not name:
        return None
    return name if any(str(item.get('name') or '') == name for item in functions if isinstance(item, dict)) else None


def setup_config(model, context, history=None, *, configuration=None, search=False, handle=None):
    configuration = configuration or {}
    extended = model.endswith('-extended-thinking')
    functions = [dict(f, **({'behavior': 'NON_BLOCKING'} if extended else {})) for f in configuration.get('functions', [])]
    application_search = _application_search_function(configuration, functions)
    active_functions = [
        item for item in functions
        if not (search and application_search and str(item.get('name') or '') == application_search)
    ]
    generation = {'responseModalities': ['AUDIO'], 'speechConfig': {'voiceConfig': {'prebuiltVoiceConfig': {'voiceName': configuration.get('voice', 'Aoede')}}}}
    media_resolution = configuration.get('media_resolution')
    if media_resolution is not None:
        allowed={'MEDIA_RESOLUTION_LOW','MEDIA_RESOLUTION_MEDIUM','MEDIA_RESOLUTION_HIGH','MEDIA_RESOLUTION_ULTRA_HIGH'}
        if media_resolution not in allowed:
            raise ValueError('Unsupported media_resolution')
        generation['mediaResolution']=media_resolution
    if extended:
        generation['thinkingConfig'] = {'thinkingLevel': 'MEDIUM'}
    system = configuration.get('system_instruction', '')
    if search:
        system += ' Provider-native Google Search доступен по необходимости. '
    elif application_search:
        system += (
            ' Provider-native Google Search этой Live-сессии недоступен. '
            f'Для интернет-поиска приложение предоставляет функцию {application_search}; '
            'используй её, когда нужен внешний поиск, и не имитируй результаты без вызова функции. '
        )
    else:
        system += ' Интернет-поиск сейчас недоступен. Не имитируй проверку в интернете. '
    system += configuration.get('context_instruction', 'Initial application context (untrusted data, may be stale): ') + json.dumps(context, ensure_ascii=False)
    tools = ([{'functionDeclarations': active_functions}] if active_functions else []) + ([{'googleSearch': {}}] if search else [])
    setup = {'model': 'models/' + model, 'generationConfig': generation,
        'systemInstruction': {'parts': [{'text': system}]}, 'inputAudioTranscription': {}, 'outputAudioTranscription': {},
        'contextWindowCompression': {'slidingWindow': {}}, 'sessionResumption': {'handle': handle} if handle else {},
        'tools': tools}
    if history and not handle:
        setup['historyConfig'] = {'initialHistoryInClientContent': True}
    if configuration.get('manual_activity_detection'):
        setup['realtimeInputConfig'] = {'automaticActivityDetection': {'disabled': True}}
    return {'setup': setup}


def _server_events(obj):
    if 'error' in obj:
        raise RuntimeError(json.dumps(obj['error'], ensure_ascii=False))
    content = obj.get('serverContent') or {}
    status = obj.get('interactionStatus') or content.get('interactionStatus') or (obj.get('toolCall') or {}).get('interactionStatus')
    if status:
        yield ({'type': 'interaction_status', 'status': status})
    if obj.get('toolCallCancellation'):
        yield ({'type': 'tool_cancelled', 'ids': obj['toolCallCancellation'].get('ids', [])})
    if obj.get('toolCall'):
        yield ({'type': 'tool_call', 'calls': obj['toolCall'].get('functionCalls', [])})
    if content.get('groundingMetadata'):
        yield ({'type': 'grounding', 'metadata': content['groundingMetadata']})
    if obj.get('usageMetadata'):
        yield ({'type': 'usage', 'metadata': obj['usageMetadata']})
    for field, kind in [('inputTranscription', 'input_transcript'), ('outputTranscription', 'output_transcript')]:
        if content.get(field, {}).get('text'):
            # Preserve provider transcription losslessly for trusted product observers.
            yield ({'type': kind, 'text': content[field]['text']})
    if content.get('interrupted'):
        yield ({'type': 'interrupted'})
    for part in (content.get('modelTurn') or {}).get('parts', []):
        data = part.get('inlineData') or {}
        if str(data.get('mimeType', '')).startswith('audio/pcm') and data.get('data'):
            try:
                raw = base64.b64decode(data['data'], validate=True)
            except (ValueError, TypeError):
                raw = None
            if not raw or len(raw) % 2:
                # Preserve invalid metadata for the existing strict consumer
                # gate; normalization must not repair or silently drop it.
                yield {'type': 'audio', 'mime_type': data.get('mimeType'), 'data': data['data']}
                continue
            for offset in range(0, len(raw), OUTPUT_PCM_CHUNK_BYTES):
                yield {'type': 'audio', 'mime_type': data.get('mimeType'),
                       'data': base64.b64encode(raw[offset:offset + OUTPUT_PCM_CHUNK_BYTES]).decode('ascii')}
    if content.get('generationComplete'):
        yield ({'type': 'generation_complete'})
    if content.get('turnComplete'):
        yield ({'type': 'turn_complete'})


def handle_server_message(obj, emit=emit):
    for event in _server_events(obj):
        emit(event)


async def handle_server_message_async(obj, emit=emit, *, stopped=lambda: False, resource_guard=None):
    for event in _server_events(obj):
        if stopped():
            return
        _guard_check(resource_guard)
        result = emit(event)
        if inspect.isawaitable(result):
            await result
        await asyncio.sleep(0)
    # Buffered ws.recv() is allowed to complete immediately. Yield even for
    # metadata-only messages so Stop and other shared tasks keep progressing.
    await asyncio.sleep(0)


async def run(*, load_key=default_key, reader=None, on_event=emit, resource_guard=None):
    from websockets import connect
    emit = on_event
    loop = asyncio.get_running_loop()
    # Images are bounded to 512 KiB before base64 by the runtime.
    if reader is None:
        reader = asyncio.StreamReader(limit=1024 * 1024)
        await loop.connect_read_pipe(lambda: asyncio.StreamReaderProtocol(reader), sys.stdin.buffer)
    start = await read_line(reader)
    if not start or start.get('type') != 'start':
        raise ValueError('missing_start')
    model = start.get('model', 'gemini-3.8-live')
    if model not in MODELS:
        raise ValueError('invalid_model')
    _guard_check(resource_guard)
    key = resource_guard.key() if resource_guard is not None else load_key()
    if not key:
        emit({'type': 'error', 'code': 'LIVE_UNAVAILABLE', 'message': 'application_google_binding_missing'})
        return
    state = {
        'ws': None,
        'stopped': False,
        'handle': None,
        'handle_event': asyncio.Event(),
        'handle_generation': 0,
        'transition_handle_event': asyncio.Event(),
        'transition_started_event': asyncio.Event(),
        'transition_wait': None,
        'drop_inputs_before': 0,
        'drop_capture_before': 0,
        'context': start.get('context') or {},
        'configuration': start.get('configuration', {}) or {},
        'reconnects': 0,
        'connection_generation': 0,
        'resource_error': None,
        'transition': None,
        'search_disabled_by_quota': False,
    }
    dialogue = DialogueHistory(start.get('history'))
    def emit_observed(event):
        if event.get('type') == 'input_transcript':
            dialogue.transcript('user', event.get('text'))
        elif event.get('type') == 'output_transcript':
            dialogue.transcript('model', event.get('text'))
        elif event.get('type') in ('turn_complete', 'interrupted', 'tool_call'):
            dialogue.complete()
        emit(event)
    declared_functions = state['configuration'].get("functions", [])
    application_search = _application_search_function(state['configuration'], declared_functions)
    search = bool(state['configuration'].get("search_enabled", False))
    if not search and not application_search:
        emit({"type":"capability_unavailable","capability":"internet_search","code":"NOT_CONFIGURED","message":"Интернет-поиск не настроен приложением."})

    async def sender():
        audio_chunks = 0
        max_stdin_delay_ms = max_ws_send_ms = 0
        while not state['stopped']:
            message = await read_line(reader)
            if message is None or message.get('type') == 'stop':
                state['stopped'] = True
                if state['ws']:
                    await state['ws'].close()
                return
            kind = message.get('type')
            if kind == 'snapshot':
                state['context'] = message.get('context') or {}
            if kind == 'reconfigure':
                transition_id = str(message.get('transition_id') or '')[:120]
                capability = str(message.get('capability') or '')[:80]
                configuration = message.get('configuration')
                context = message.get('context')
                router_response = message.get('router_response')
                continuation = message.get('continuation') or ''
                if (not transition_id or not capability or not isinstance(configuration, dict)
                        or not isinstance(router_response, dict) or not isinstance(continuation, str)
                        or len(continuation) > 1200):
                    emit({'type':'capability_transition_error','transition_id':transition_id,'capability':capability,'code':'LIVE_RECONFIGURE_INVALID'})
                    continue
                try:
                    serialized = json.dumps(configuration, ensure_ascii=False, separators=(',', ':')).encode()
                    response_bytes = json.dumps(router_response, ensure_ascii=False, separators=(',', ':')).encode()
                except (TypeError, ValueError, UnicodeError):
                    emit({'type':'capability_transition_error','transition_id':transition_id,'capability':capability,'code':'LIVE_RECONFIGURE_INVALID'})
                    continue
                functions = configuration.get('functions') or []
                if (len(serialized) > 262144 or len(response_bytes) > 16384
                        or not isinstance(functions, list) or len(functions) > 9):
                    emit({'type':'capability_transition_error','transition_id':transition_id,'capability':capability,'code':'LIVE_RECONFIGURE_LIMIT'})
                    continue
                ws = state['ws']
                if not ws:
                    emit({'type':'capability_transition_error','transition_id':transition_id,'capability':capability,'code':'LIVE_RESUMPTION_UNAVAILABLE'})
                    continue
                wait = {'baseline':state['handle_generation'],'router_response_sent':False}
                state['transition_wait'] = wait
                state['transition_handle_event'].clear()
                state['transition_started_event'].clear()
                state['handle'] = None
                state['handle_event'].clear()
                try:
                    await _guarded_send(ws, {'toolResponse': {'functionResponses': [router_response]}}, resource_guard)
                    wait['router_response_sent'] = True
                    emit({'type':'capability_transition_acknowledged','transition_id':transition_id,'capability':capability})
                    await asyncio.wait_for(state['transition_handle_event'].wait(), timeout=FRESH_HANDLE_WAIT_SECONDS)
                    if wait.get('connection_closed'):
                        raise ConnectionError('router connection closed before fresh checkpoint')
                except (TimeoutError, ConnectionClosed, ConnectionError) as exc:
                    if _is_resource_failure(exc):
                        raise
                    # The provider can finish the router call yet never issue a
                    # post-response checkpoint, or close before acknowledging it.
                    # The old handle is unsafe. Restore bounded dialogue context
                    # on a new connection with the same model/key and intent.
                    state['handle'] = None
                    emit({'type':'capability_transition_recovered','transition_id':transition_id,
                          'capability':capability,'reason':'router_connection_closed' if not isinstance(exc,TimeoutError) else 'fresh_handle_unavailable',
                          **dialogue.metrics()})
                state['transition_wait'] = None
                state['configuration'] = configuration
                if isinstance(context, dict):
                    state['context'] = context
                state['transition'] = {'transition_id':transition_id,'capability':capability,
                                       'continuation':continuation.strip(),
                                       'deadline':loop.time()+TRANSITION_DEADLINE_SECONDS,
                                       'attempts':0}
                state['transition_started_event'].set()
                state['drop_inputs_before'] = round(time.time() * 1000)
                emit({'type':'capability_transition_started','transition_id':transition_id,'capability':capability})
                await ws.close()
                continue
            ws = state['ws']
            # Drop capture during an outage. Never queue or replay old speech.
            if not ws:
                continue
            if kind in ('audio','audio_stream_end','activity_start','activity_end','text','snapshot') and message.get('queued_at', 0) <= state['drop_inputs_before']:
                emit({'type':'input_dropped','reason':'capability_transition','input_type':kind})
                continue
            # Resource waits invalidate real-time capture. Explicit text remains
            # ordered in the input queue; it is not stale microphone replay.
            if kind in ('audio','audio_stream_end','activity_start','activity_end','snapshot') and message.get('queued_at', 0) <= state['drop_capture_before']:
                emit({'type':'input_dropped','reason':'resource_budget','input_type':kind})
                continue
            if kind == 'audio':
                if audio_chunks == 0:
                    dialogue.input_started()
                payload = {'realtimeInput': {'audio': {'data': message.get('data', ''), 'mimeType': 'audio/pcm;rate=16000'}}}
            elif kind == 'audio_stream_end':
                payload = {'realtimeInput': {'audioStreamEnd': True}}
            elif kind == 'activity_start':
                dialogue.input_started()
                payload = {'realtimeInput': {'activityStart': {}}}
            elif kind == 'activity_end':
                payload = {'realtimeInput': {'activityEnd': {}}}
            elif kind == 'text':
                dialogue.input_started()
                payload = {'clientContent': {'turns': [{'role': 'user', 'parts': [{'text': message.get('text', '')}]}], 'turnComplete': True}}
            elif kind == 'snapshot':
                # Video stream frames do not end a user turn or interrupt playback.
                payload = {'realtimeInput': {'video': {'data': message.get('data', ''), 'mimeType': message.get('mime_type', 'image/jpeg')}}}
            elif kind == 'tool_response':
                payload = {'toolResponse': {'functionResponses': message.get('responses', [])}}
            else:
                continue
            try:
                started_ms = round(time.time() * 1000)
                if kind in ('audio', 'audio_stream_end'):
                    max_stdin_delay_ms = max(max_stdin_delay_ms, max(0, started_ms - message.get('queued_at', started_ms)))
                    audio_chunks += int(kind == 'audio')
                sent = await _send_with_budget_wait(ws,payload,resource_guard,emit,kind,state,optional=message.get('optional') is True)
                if not sent:
                    continue
                if kind == 'text':
                    dialogue.transcript('user', message.get('text'))
                    dialogue.complete()
                if kind in ('audio', 'audio_stream_end'):
                    max_ws_send_ms = max(max_ws_send_ms, round(time.time() * 1000) - started_ms)
                if kind == 'text':
                    emit({'type': 'input_timing', 'text_sent_at': round(time.time() * 1000)})
                if kind in ('audio_stream_end', 'activity_end'):
                    timing = {'type': 'input_timing', 'audio_chunks': audio_chunks, 'max_stdin_delay_ms': max_stdin_delay_ms, 'max_ws_send_ms': max_ws_send_ms}
                    timing['audio_stream_end_sent_at' if kind == 'audio_stream_end' else 'activity_end_sent_at'] = round(time.time() * 1000)
                    emit(timing)
                    audio_chunks = 0
                    max_stdin_delay_ms = max_ws_send_ms = 0
            except Exception as exc:
                state['ws'] = None
                if _is_resource_failure(exc):
                    state['resource_error'] = exc
                    state['stopped'] = True
                    try:
                        await ws.close()
                    except Exception:
                        pass
                    raise
                # Receiver owns bounded reconnect; sender remains alive to accept Stop.

    sender_task = asyncio.create_task(sender())
    try:
        while not state['stopped']:
            try:
                _guard_check(resource_guard)
                transition = state.get('transition')
                if transition:
                    if (transition['attempts'] >= MAX_TRANSITION_CONNECTION_ATTEMPTS
                            or loop.time() >= transition['deadline']):
                        emit({'type':'capability_transition_error',
                              'transition_id':transition['transition_id'],
                              'capability':transition['capability'],
                              'code':'LIVE_CAPABILITY_TIMEOUT',
                              'connection_generation':state['connection_generation']})
                        state['stopped'] = True
                        break
                    transition['attempts'] += 1
                state['connection_generation'] += 1
                configuration = state['configuration']
                declared_functions = configuration.get('functions', [])
                application_search = _application_search_function(configuration, declared_functions)
                search = bool(configuration.get('search_enabled', False)) and not state['search_disabled_by_quota']
                remaining = max(.001, transition['deadline']-loop.time()) if transition else 15
                async with connect(ENDPOINT + '?key=' + quote(key, safe=''), open_timeout=min(15,remaining), close_timeout=2, max_size=8 * 1024 * 1024) as ws:
                    history = [] if state['handle'] else dialogue.snapshot()
                    setup = setup_config(model, state['context'], history, configuration=configuration, search=search, handle=state['handle'])
                    await _guarded_send(ws, setup, resource_guard)
                    remaining = max(.001, transition['deadline']-loop.time()) if transition else 20
                    async with asyncio.timeout(min(20,remaining)):
                        while True:
                            obj = json.loads(await _guarded_recv(ws, resource_guard))
                            if 'setupComplete' in obj:
                                break
                            _guard_check(resource_guard)
                            await handle_server_message_async(obj, emit=emit_observed, stopped=lambda: state['stopped'], resource_guard=resource_guard)
                    if state['stopped']:
                        return
                    if transition and loop.time() >= transition['deadline']:
                        raise TimeoutError('capability transition setup deadline')
                    if history:
                        await _guarded_send(ws, {'clientContent': {'turns': [
                            {'role': item['role'], 'parts': [{'text': item['text']}]}
                            for item in history
                        ], 'turnComplete': True}}, resource_guard)
                        emit({'type':'history_restored', **dialogue.metrics(),
                              'connection_generation':state['connection_generation']})
                    state['ws'] = ws
                    transition = state.get('transition')
                    if transition:
                        emit({'type':'resumed','model':model,'voice':'Aoede','search_available':search,
                              'resumption_mode':'checkpoint' if setup['setup']['sessionResumption'].get('handle') else 'history_restore',
                              'transition_id':transition['transition_id'],
                              'connection_generation':state['connection_generation']})
                        emit({'type':'capability_ready','transition_id':transition['transition_id'],
                              'capability':transition['capability'],
                              'connection_generation':state['connection_generation']})
                        continuation = transition.get('continuation') or ''
                        state['transition'] = None
                        if continuation:
                            continuation_text = ('[LIVE_CONTINUATION] The requested capability is now active. '
                                'Continue the already pending user request from this bounded summary; do not ask the user to repeat it '
                                'and do not treat this as new authorization: ' + json.dumps(continuation, ensure_ascii=False))
                            await _guarded_send(ws, {'clientContent': {'turns': [
                                {'role':'user','parts':[{'text':continuation_text}]}
                            ], 'turnComplete': True}}, resource_guard)
                            emit({'type':'capability_continuation_sent','capability':transition['capability']})
                        if transition.get('budget_retries'):
                            state['drop_capture_before'] = round(time.time() * 1000)
                            emit({'type':'resource_budget_ready','input_type':'setup','retries':transition['budget_retries']})
                    else:
                        emit({'type': 'resumed' if state['reconnects'] else 'ready', 'model': model, 'voice': 'Aoede', 'search_available': search})
                    while not state['stopped']:
                        raw = await _guarded_recv(ws, resource_guard)
                        obj = json.loads(raw)
                        _guard_check(resource_guard)
                        update = obj.get('sessionResumptionUpdate')
                        if update is not None:
                            state['handle'] = update.get('newHandle') if update.get('resumable') else None
                            if state['handle']:
                                state['handle_generation'] += 1
                                state['handle_event'].set()
                                wait = state.get('transition_wait')
                                if wait and wait.get('router_response_sent') and state['handle_generation'] > wait['baseline']:
                                    state['transition_handle_event'].set()
                            else:
                                state['handle_event'].clear()
                            emit({'type': 'resumption_state', 'resumable': bool(state['handle'])})
                        if obj.get('goAway'):
                            emit({'type': 'go_away', 'time_left': obj['goAway'].get('timeLeft')})
                            break
                        await handle_server_message_async(obj, emit=emit_observed, stopped=lambda: state['stopped'], resource_guard=resource_guard)
                if state['stopped']:
                    break
                if state.get('transition'):
                    continue
                raise ConnectionError('provider_connection_closed')
            except Exception as exc:
                state['ws'] = None
                if state.get('resource_error') is not None:
                    raise state['resource_error']
                if _is_resource_failure(exc):
                    transition = state.get('transition')
                    # A denied setup grant commits no tokens. During a tool-bundle
                    # switch the previous socket is already closed, so wait for a
                    # short rolling-budget refill within the existing deadline.
                    if (transition and getattr(exc, 'code', None) == 'RESOURCE_TOKEN_BUDGET'
                            and transition.get('budget_retries', 0) < MAX_TRANSITION_BUDGET_RETRIES
                            and transition['deadline'] - loop.time() > TRANSITION_BUDGET_RETRY_SECONDS + 1):
                        transition['budget_retries'] = transition.get('budget_retries', 0) + 1
                        transition['attempts'] -= 1
                        emit({'type': 'capability_budget_wait',
                              'transition_id': transition['transition_id'],
                              'capability': transition['capability'],
                              'retry': transition['budget_retries'],
                              'wait_ms': TRANSITION_BUDGET_RETRY_SECONDS * 1000})
                        emit({'type':'resource_budget_wait','input_type':'setup',
                              'retry':transition['budget_retries'],
                              'wait_ms':TRANSITION_BUDGET_RETRY_SECONDS * 1000})
                        await asyncio.sleep(TRANSITION_BUDGET_RETRY_SECONDS)
                        continue
                    raise
                wait = state.get('transition_wait')
                if wait is not None:
                    wait['connection_closed'] = True
                    state['transition_handle_event'].set()
                    try:
                        await asyncio.wait_for(state['transition_started_event'].wait(), timeout=1)
                    except TimeoutError:
                        pass
                if state.get('transition'):
                    continue
                message = str(exc).replace(key, '[REDACTED]').replace(quote(key, safe=''), '[REDACTED]')
                if search and not state['reconnects'] and 'quota' in message.lower():
                    state['search_disabled_by_quota'] = True
                    search = False
                    if application_search:
                        emit({
                            'type': 'capability_unavailable',
                            'capability': 'google_search_native',
                            'code': 'PROVIDER_QUOTA',
                            'message': f'Встроенный Google Search недоступен; приложение продолжает поиск через {application_search}.',
                        })
                    else:
                        emit({'type': 'capability_unavailable', 'capability': 'internet_search', 'code': 'PROVIDER_QUOTA', 'message': 'Интернет-поиск недоступен: квота провайдера. Голосовой разговор доступен.'})
                    continue
                if state['stopped']:
                    break
                if not state['handle'] or state['reconnects'] >= 3 or any(x in message.lower() for x in ['permission', 'unauthorized', 'api key', 'quota']):
                    raise
                state['reconnects'] += 1
                emit({'type': 'reconnecting', 'attempt': state['reconnects']})
                await asyncio.sleep(min(2, state['reconnects'] * .5))
    except Exception as exc:
        if _is_resource_failure(exc):
            raise
        message = str(exc).replace(key, '[REDACTED]').replace(quote(key, safe=''), '[REDACTED]')
        emit({'type': 'error', 'code': type(exc).__name__, 'message': re.sub(r'AIza[A-Za-z0-9_-]{20,}', '[REDACTED]', message)[:500]})
    finally:
        state['stopped'] = True
        sender_task.cancel()
        await asyncio.gather(sender_task, return_exceptions=True)


if __name__ == '__main__':
    logging.disable(logging.CRITICAL)
    asyncio.run(run())
